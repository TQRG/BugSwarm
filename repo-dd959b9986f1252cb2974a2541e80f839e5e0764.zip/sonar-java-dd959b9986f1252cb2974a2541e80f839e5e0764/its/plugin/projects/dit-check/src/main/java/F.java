public class F extends E {
  @Override
  public int method(int a) {
    return a;
  }
}
