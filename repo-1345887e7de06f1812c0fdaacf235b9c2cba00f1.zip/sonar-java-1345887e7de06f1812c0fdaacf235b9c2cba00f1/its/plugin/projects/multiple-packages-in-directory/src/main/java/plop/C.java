package plop;

import bar.B;

public class C {
  foo.A a;
  B b;

}
