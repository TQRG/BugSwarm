package complexity;

// complexity: 0
public class ZeroComplexity {
}
