public class D extends C {
  @Override
  public int method(int a) {
    return a;
  }
}
