package other;

public class Bar {
  
}