import org.junit.Ignore;
import org.junit.Test;

public class IgnoredTest {
  @Test
  @Ignore
  public void ignoredTest() throws Exception {
  }
}
