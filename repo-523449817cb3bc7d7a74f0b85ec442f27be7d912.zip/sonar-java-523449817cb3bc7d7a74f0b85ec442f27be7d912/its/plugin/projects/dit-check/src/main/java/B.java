public class B extends A {
  @Override
  public int method(int a) {
    return a;
  }
}
