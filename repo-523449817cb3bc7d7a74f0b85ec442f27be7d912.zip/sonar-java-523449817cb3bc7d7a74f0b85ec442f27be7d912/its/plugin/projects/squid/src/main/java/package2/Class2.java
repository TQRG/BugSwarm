package package2;

import package1.Class1;

public class Class2 {
  public Class1 method() {
    return null;
  }

  enum EmptyEnum {

  }
}
