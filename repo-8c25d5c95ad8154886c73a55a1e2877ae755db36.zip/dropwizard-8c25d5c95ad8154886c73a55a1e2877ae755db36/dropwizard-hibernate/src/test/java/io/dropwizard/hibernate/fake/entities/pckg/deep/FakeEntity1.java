package io.dropwizard.hibernate.fake.entities.pckg.deep;

import javax.persistence.Entity;

@Entity
public class FakeEntity1 {

}
