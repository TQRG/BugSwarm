package io.dropwizard.hibernate.fake2.entities.pckg.deep;
import javax.persistence.Entity;

@Entity
public class FakeEntity1 {

}
