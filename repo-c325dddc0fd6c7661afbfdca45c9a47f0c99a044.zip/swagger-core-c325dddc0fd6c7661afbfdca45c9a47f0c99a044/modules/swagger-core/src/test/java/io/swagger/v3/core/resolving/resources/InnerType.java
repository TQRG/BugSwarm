package io.swagger.v3.core.resolving.resources;

public class InnerType {
    public int foo;
    public String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}