from typing import Optional, Tuple
STRICT_OPTIONAL = False
find_occurrences = None  # type: Optional[Tuple[str, str]]
