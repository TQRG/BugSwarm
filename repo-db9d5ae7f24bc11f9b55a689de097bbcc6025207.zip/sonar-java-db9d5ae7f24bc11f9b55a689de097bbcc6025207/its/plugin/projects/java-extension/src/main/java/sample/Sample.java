package sample;

public class Sample {
	
	public Sample(int i) {
		int j = i++;
	}
	
	private String firstMethod() {
		return "one";
	}

  private String secondMethod() {
		return "two";
	}

  private String thirdMethod() {
		return "three";
	}
}
