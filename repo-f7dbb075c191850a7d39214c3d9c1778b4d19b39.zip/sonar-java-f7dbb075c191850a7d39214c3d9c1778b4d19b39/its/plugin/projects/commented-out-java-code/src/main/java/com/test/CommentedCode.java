package com.test;

import java.io.PrintWriter;

/**
 * Commented Code
 */
public class CommentedCode {

    public void test(PrintWriter pw) {
      System.out.println("this code is not commented");
    }
    
    //public void test1(PrintWriter pw) {
    //    System.out.println("this code seems to be commented");
    //}
    
    /*public void test1(PrintWriter pw) {
        System.out.println("this code seems also to be commented");
    }*/
    
    /**
     * public boolean test2(PrintWriter pw) {
     *   System.out.println("this code is not considered as commented");
     *   return true;
     * }
     */
}