package io.swagger.servlet.resources;

import io.swagger.annotations.Api;

@Api(hidden = true)
public class HiddenResource {

}
