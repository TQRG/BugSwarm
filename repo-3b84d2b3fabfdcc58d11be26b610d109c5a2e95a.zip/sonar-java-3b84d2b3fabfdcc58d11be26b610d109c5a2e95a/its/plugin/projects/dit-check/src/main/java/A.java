public class A {
  public int method(int a) {
    return a;
  }
}
