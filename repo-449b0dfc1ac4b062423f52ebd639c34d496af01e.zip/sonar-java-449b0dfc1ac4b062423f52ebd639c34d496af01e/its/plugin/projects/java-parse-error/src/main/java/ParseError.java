class A {
  void foo() {

}
