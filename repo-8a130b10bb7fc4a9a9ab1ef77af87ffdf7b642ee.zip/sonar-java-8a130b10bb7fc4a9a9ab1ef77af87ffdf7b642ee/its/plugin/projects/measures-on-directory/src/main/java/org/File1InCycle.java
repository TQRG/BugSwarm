package org;

class File1InCycle {
  File2InCycle field;
}
