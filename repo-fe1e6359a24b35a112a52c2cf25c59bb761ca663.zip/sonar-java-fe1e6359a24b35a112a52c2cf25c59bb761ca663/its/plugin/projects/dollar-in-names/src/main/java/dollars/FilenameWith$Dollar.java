package dollars;

public class FilenameWith$Dollar {
	public static String s=null;
	
	public String toString() {
		while(true) 
		  s="dollar";	
	}
}