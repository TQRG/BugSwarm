Mypy Sample Programs
--------------------

The sample programs use static typing unless otherwise noted in comments.

Original credits for sample programs:

  fib.py - Python Wiki [1]
  for.py - Python Wiki [1]
  greet.py - Python Wiki [1]
  hello.py - Python Wiki [1]
  input.py - Python Wiki [1]
  regexp.py - Python Wiki [1]
  dict.py - Python Wiki [1]
  cmdline.py - Python Wiki [1]
  files.py - Python Wiki [1]
  bottles.py - Python Wiki [1]
  class.py - Python Wiki [1]
  guess.py - Python Wiki [1]
  generators.py - Python Wiki [1]
  itertool.py - Python Wiki [1]

The sample programs were ported to mypy by Jukka Lehtosalo.

[1] http://wiki.python.org/moin/SimplePrograms
