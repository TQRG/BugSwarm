Additional features
-------------------

Several mypy features are not currently covered by this tutorial,
including the following:

- inheritance between generic classes
- compatibility and subtyping of generic types, including covariance of generic types
- ``super()``
