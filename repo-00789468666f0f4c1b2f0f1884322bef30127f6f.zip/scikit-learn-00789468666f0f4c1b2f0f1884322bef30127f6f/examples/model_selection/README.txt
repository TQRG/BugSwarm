.. _model_selection_examples:

Model Selection
-----------------------

Examples related to the :mod:`sklearn.model_selection` module.
