public class E extends D {
  @Override
  public int method(int a) {
    return a;
  }
}
