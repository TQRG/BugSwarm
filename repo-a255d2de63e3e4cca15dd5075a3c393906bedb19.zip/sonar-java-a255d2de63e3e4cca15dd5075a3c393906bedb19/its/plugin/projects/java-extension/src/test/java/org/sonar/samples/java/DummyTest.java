package org.sonar.samples.java;

import junit.framework.Assert;
import org.junit.Test;

public class DummyTest {
  @Test
  public void my_clever_test() throws Exception {
    Assert.assertEquals(true, true);
  }
}
