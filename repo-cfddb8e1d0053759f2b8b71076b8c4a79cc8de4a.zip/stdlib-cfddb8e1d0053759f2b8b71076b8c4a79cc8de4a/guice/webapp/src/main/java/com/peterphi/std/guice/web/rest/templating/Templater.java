package com.peterphi.std.guice.web.rest.templating;

public interface Templater
{
	public TemplateCall template(String name);
}
