@javax.xml.bind.annotation.XmlSchema(
		                                    xmlns = {@XmlNs(prefix = "q", namespaceURI = "http://ns.peterphi.com/stdlib/webquery/1.0")},
		                                    namespace = "http://ns.peterphi.com/stdlib/webquery/1.0",
		                                    elementFormDefault = XmlNsForm.QUALIFIED)
//
		package com.peterphi.std.guice.restclient.jaxb.webquery;

import javax.xml.bind.annotation.XmlNs;
import javax.xml.bind.annotation.XmlNsForm;
