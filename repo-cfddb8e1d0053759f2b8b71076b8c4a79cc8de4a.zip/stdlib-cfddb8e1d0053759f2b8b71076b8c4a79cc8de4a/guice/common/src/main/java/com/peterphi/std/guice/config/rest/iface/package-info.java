@ServiceName("config")
package com.peterphi.std.guice.config.rest.iface;

import com.peterphi.std.annotation.ServiceName;
