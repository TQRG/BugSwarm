@ServiceName("service-manager")
package com.peterphi.std.guice.common.logging.rest.iface;

import com.peterphi.std.annotation.ServiceName;
