package com.peterphi.std.guice.hibernate.webquery;

public interface HQLEncodingContext
{
	String createPropertyPlaceholder(final Object value);
}
