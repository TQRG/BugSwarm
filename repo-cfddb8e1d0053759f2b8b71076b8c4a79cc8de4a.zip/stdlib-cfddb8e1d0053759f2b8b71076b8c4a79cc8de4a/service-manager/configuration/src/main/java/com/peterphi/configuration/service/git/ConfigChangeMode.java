package com.peterphi.configuration.service.git;

public enum ConfigChangeMode
{
	WIPE_ALL,
	WIPE_REFERENCED_PATHS,
	ADD_AND_MODIFY_ONLY;
}
