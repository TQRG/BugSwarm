"""Mypy type checker command line tool."""

from mypy.main import main

main(None)
