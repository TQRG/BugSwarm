pytest_plugins = [
    'mypy.test.data',
]
