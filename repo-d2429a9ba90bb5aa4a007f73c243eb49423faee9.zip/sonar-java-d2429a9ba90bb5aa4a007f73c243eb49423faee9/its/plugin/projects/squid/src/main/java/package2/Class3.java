package package2;

import package1.Class1;

public class Class3 {
  public Class1 method() {
    return null;
  }
}
