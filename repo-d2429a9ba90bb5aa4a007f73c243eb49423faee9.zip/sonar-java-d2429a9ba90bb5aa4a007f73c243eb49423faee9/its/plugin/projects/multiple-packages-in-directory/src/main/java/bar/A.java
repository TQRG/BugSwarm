package foo;

import plop.C;

public class A {
  C c;
}
