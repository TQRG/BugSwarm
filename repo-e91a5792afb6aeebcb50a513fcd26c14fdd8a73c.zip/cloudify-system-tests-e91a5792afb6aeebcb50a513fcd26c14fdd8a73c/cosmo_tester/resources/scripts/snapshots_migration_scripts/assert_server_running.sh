#!/usr/bin/env bash

set -eax

curl -I `cat $server_url`