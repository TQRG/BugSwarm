package io.swagger.v3.core.oas.models;

public class SpecialOrderItem {
    public String name;
    public Long id;
}