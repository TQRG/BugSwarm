package io.swagger.v3.jaxrs2.resources;

public class BasicClass {
    public void emptyMethod() {
    }
}