package io.swagger.v3.jaxrs2.petstore;

/**
 * An Empty PetResource Class
 */
public class EmptyPetResource {
}
