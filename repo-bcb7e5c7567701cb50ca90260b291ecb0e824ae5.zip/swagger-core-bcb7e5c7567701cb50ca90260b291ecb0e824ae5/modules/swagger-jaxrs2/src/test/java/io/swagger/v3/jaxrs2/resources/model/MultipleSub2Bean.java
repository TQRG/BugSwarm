package io.swagger.v3.jaxrs2.resources.model;

@io.swagger.v3.oas.annotations.media.Schema(
        description = "MultipleSub2Bean"
)
public class MultipleSub2Bean extends MultipleBaseBean {
    public int d;
}