public class C extends B {
  @Override
  public int method(int a) {
    return a;
  }
}
