package io.swagger.v3.core.oas.models;

public class Children {
    public String getName() {
        return null;
    }

    public void setName(String name) {
    }
}
