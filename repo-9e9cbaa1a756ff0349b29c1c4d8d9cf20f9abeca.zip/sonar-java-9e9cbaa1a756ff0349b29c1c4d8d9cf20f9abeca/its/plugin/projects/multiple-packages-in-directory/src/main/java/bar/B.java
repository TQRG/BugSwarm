package bar;

import plop.C;

public class B {
  C c;
}
