package io.swagger.v3.oas.integration.api;

public interface OpenAPIConfigBuilder {
    OpenAPIConfiguration build();
}