package io.swagger.v3.oas.integration;

public class OpenApiConfigurationException extends Exception {

    public OpenApiConfigurationException(String message, Throwable cause) {
        super(message, cause);
    }
}
