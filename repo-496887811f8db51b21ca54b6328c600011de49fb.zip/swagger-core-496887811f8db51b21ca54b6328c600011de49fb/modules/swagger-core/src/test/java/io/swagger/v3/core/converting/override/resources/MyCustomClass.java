package io.swagger.v3.core.converting.override.resources;

public class MyCustomClass {
    // does nothing, really
}
