package io.swagger.v3.core.util;

public final class Constants {
    public final static String COMMA = ",";
}
