package io.swagger.v3.jaxrs2.resources;

import javax.ws.rs.core.Response;

public class Ticket2644ConcreteImplementation implements Ticket2644AnnotatedInterface {
    public Response getResource() {
        // Get the resource
        return null;
    }
}
