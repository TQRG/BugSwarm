package io.swagger.v3.jaxrs2.petstore.example;

public class SubscriptionResponse {
    public String subscriptionId;
}