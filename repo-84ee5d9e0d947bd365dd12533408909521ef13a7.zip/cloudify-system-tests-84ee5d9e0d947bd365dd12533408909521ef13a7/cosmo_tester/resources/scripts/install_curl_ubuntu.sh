apt-get -q -y install curl
