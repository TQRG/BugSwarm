public class Helloworld2 {

  public void printHelloWorld2() {
    System.out.println("Hello World 2!");
  }
  
}
