package com.peterphi.std.guice.restclient.exception;

public class RestThrowableConstants
{
	public static final String HEADER_RICH_EXCEPTION = "X-Rich-Exception";
}
