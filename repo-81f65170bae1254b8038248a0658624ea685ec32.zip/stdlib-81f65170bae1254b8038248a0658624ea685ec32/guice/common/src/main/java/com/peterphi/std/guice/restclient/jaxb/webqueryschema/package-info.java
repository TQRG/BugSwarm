@javax.xml.bind.annotation.XmlSchema(
		                                    xmlns = {@XmlNs(prefix = "schema", namespaceURI = "http://ns.peterphi.com/stdlib/webquery/1.0/schema")},
		                                    namespace = "http://ns.peterphi.com/stdlib/webquery/1.0/schema",
		                                    elementFormDefault = XmlNsForm.QUALIFIED)
//
		package com.peterphi.std.guice.restclient.jaxb.webqueryschema;

import javax.xml.bind.annotation.XmlNs;
import javax.xml.bind.annotation.XmlNsForm;

