package com.peterphi.std.com.peterphi.std.guice.testing.annotations;

interface SomeInterface
{
	public String whoami();
}
