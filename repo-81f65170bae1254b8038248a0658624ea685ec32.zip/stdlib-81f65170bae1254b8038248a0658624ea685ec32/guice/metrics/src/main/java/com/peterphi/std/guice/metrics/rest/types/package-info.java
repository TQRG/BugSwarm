@javax.xml.bind.annotation.XmlSchema(namespace = "http://ns.peterphi.com/stdlib/rest/metrics",
                                     elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED) //
		package com.peterphi.std.guice.metrics.rest.types;

