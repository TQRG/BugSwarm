package com.peterphi.servicemanager.hostagent.webapp.guice;

import com.google.inject.AbstractModule;

public class HostAgentModule extends AbstractModule
{
	@Override
	protected void configure()
	{

	}
}
