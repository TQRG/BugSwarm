@ServiceName("service-manager")
package com.peterphi.servicemanager.service.rest.resource.iface;

import com.peterphi.std.annotation.ServiceName;
