@javax.xml.bind.annotation.XmlSchema(namespace = "http://ns.peterphi.com/stdlib/service-manager/host-agent/v1", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.peterphi.servicemanager.hostagent.rest.type;
