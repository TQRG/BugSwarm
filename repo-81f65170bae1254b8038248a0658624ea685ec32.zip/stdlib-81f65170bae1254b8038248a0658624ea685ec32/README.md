# Guice Framework for building Light RESTful Java Apps
Please [see the documentation on the wiki](https://github.com/petergeneric/stdlib/wiki)
