@javax.xml.bind.annotation.XmlSchema(namespace = "http://ns.peterphi.com/stdlib/rules",
		                                    elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.peterphi.rules.types;
