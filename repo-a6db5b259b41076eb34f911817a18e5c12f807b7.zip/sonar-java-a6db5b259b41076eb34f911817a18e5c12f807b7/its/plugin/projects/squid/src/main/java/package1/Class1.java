package package1;

import package2.Class2;

public class Class1 {
  public Class2 method() {
    return null;
  }
}
