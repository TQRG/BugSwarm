package io.dropwizard.hibernate.fake.entities.pckg;

import javax.persistence.Entity;

@Entity
public class FakeEntity1 {

}
