package org;

class File2InCycle {
  File1InCycle field;
}
